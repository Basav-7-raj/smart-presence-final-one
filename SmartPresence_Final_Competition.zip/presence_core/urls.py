from django.contrib import admin
from django.contrib.auth import views as auth_views
from django.urls import include,path
from django.conf import settings
from django.conf.urls.static import static
urlpatterns=[path('django-admin/',admin.site.urls),path('admin-login/',auth_views.LoginView.as_view(template_name='tracker/login.html'),name='login'),path('logout/',auth_views.LogoutView.as_view(),name='logout'),path('',include('tracker.urls'))]+static(settings.MEDIA_URL,document_root=settings.MEDIA_ROOT)
